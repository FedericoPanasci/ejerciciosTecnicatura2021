void datos(int vec[], int i){
    printf("ingrese un numero: ");
    scanf("%d", &vec[i]);
    
    return;
}