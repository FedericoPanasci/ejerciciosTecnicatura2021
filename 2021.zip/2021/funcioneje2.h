#include "funcioneje2.cpp"

int numAlto(int num, int alto);
int numBajo (int num, int bajo);
int promedioSum(int promedio, int suma, int i);