// ---- COMIENZO --------

// STRUCT {float precio, int cantidadVendido}
// Armo array del STRUCT con 100 posiciones.

// PASO los datos de ListaDePrecios a un array con PUP con precio y cantidad vendida en 0.


// ABRO PARA LECTURA Ventas
// LEO PRIMER REGISTRO.

// CORTE DE CONTROL

    // CALCULO IMPORTE (Busco el precio y multiplico por la cantidad)
    // ACUMULO EN EL ARRAY LA CANTIDAD PARA ESE PRODUCTO.
    // MUESTRO pedido código de producto, unidades, precio unitario e importe

    /* ---------- */

    // Informar los códigos de productos que no fueron vendidos
        // recorro el array, y muestro los que tienen cantidadVendido == 0. 
    
    // Grabo un archivo de texto con el siguiente listado
        // recorro el array, y voy grabando a un archivo codigo + (precio * cantidad)
