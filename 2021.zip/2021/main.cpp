#include <iostream>
#include "funciones.h"
using namespace std;

int main () {
    holamundo();

    system("pause");
    return 0;
}