void holamundo(){
    printf("hola mundo");
};