#include "burbujeo.cpp"

void ordenar(int arr[], int n);
void mostrar(int arr[]);