#include "consola.cpp"

void datos(int vec[], int i);